package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val edtxt1: EditText = findViewById(R.id.ednum1)
        val edtxt2: EditText = findViewById(R.id.ednum2)
        val resultTV: TextView = findViewById(R.id.resultText)
        val addButton: Button = findViewById(R.id.addBtn)
        val subButton: Button = findViewById(R.id.subBtn)
        val mulButton: Button = findViewById(R.id.mulBtn)
        val divButton: Button = findViewById(R.id.divBtn)

        addButton.setOnClickListener{
            performOperation(edtxt1, edtxt2, "Addition", resultTV)
        }
        subButton.setOnClickListener{ view ->
            performOperation(edtxt1, edtxt2, "Subtraction", resultTV)
        }
        mulButton.setOnClickListener{ view ->
            performOperation(edtxt1, edtxt2, "Multiplication", resultTV)
        }
        divButton.setOnClickListener{ view ->
            performOperation(edtxt1, edtxt2, "Division", resultTV)
        }
    }
    private fun performOperation(number1: EditText, number2: EditText, operation: String, result: TextView) {
        val num1 = number1.text.toString().toDoubleOrNull()
        val num2 = number2.text.toString().toDoubleOrNull()

        if (num1 == null || num2 == null) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        val res = when (operation) {
            "Addition" -> num1 + num2
            "Subtraction" -> num1 - num2
            "Multiplication" -> num1 * num2
            "Division" -> {
                if (num2 != 0.0) num1 / num2 else {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            else -> 0.0
        }

        result.text = "$res"
    }
}
